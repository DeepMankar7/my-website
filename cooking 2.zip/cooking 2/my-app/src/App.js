import './App.css';
import Axios from "axios";
import Home from './Components/Home';
import React, { useState, useEffect } from "react";
import { Routes, Route, BrowserRouter }from "react-router-dom"
import Main from './Components/Main';
import Loader from './Components/Loader';

function App() {

    const [search, setSearch] = useState("chicken");
 const [recipes, setRecpie] = useState([]);

  const APP_ID = "c83519d6";
  const APP_KEY = "945ec61e90ce01640c0b3dc8f317f71a";
console.log(APP_ID, APP_KEY)
  useEffect(() => {
    getRecpie();
  }, []);

  const getRecpie = async () => {
    const res = await Axios.get(`https://api.edamam.com/search?q=${search}&app_id=${APP_ID}&app_key=${APP_KEY}`);
    console.log(res)
    setRecpie(res.data.hits);
  };


  const onSearchClick = () => {
    alert("please wait...");
    getRecpie();}

 const onInputChange=(e)=>{
setSearch(e.target.value)
console.log(e.target.value)
  }
 

  return (
    <div className="container">
<BrowserRouter>

     <Routes>
      <Route path='/' element={<Main></Main>}></Route>
           <Route path='/Loader' element={<Loader></Loader>}></Route>
      <Route path='/Home' element={ <Home search={search} onInputChange={onInputChange} onSearchClick={onSearchClick} recipes={recipes}></Home>}></Route>
     </Routes> 
  </BrowserRouter>
  </div>
  );
}
export default App;


   
