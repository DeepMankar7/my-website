import React from "react";
import Dropdown from 'react-bootstrap/Dropdown';
import { Link } from "react-router-dom";
const Home = props => {
  const { recipes } = props;
  return (
<div>
 <div className="jumbotron">
      <h1 className="display-1" style={{color:"black"}}>
        <i className=" " style={{color:"black"}}>Best </i> Food Recipe<span className="material-symbols-outlined h">
restaurant
</span>
      </h1>
      <div className="input-group w-50 mx-auto">
        <input type="text" className="form-control" placeholder="Search Your Recipe..."  value={props.search} onChange={props.onInputChange}/>
        <div className="input-group-append">
         <button className="btn btn-dark p-md-3"  onClick={props.onSearchClick}>Search Recipe</button>
          
        </div>
     
      </div>
    </div>
    


    <div class="row">
      {recipes.map(recipe => (
       <div className="col-md-3">
       <div className="card py-2 text-center">
       <img src={recipe.recipe.image} className="img-fluid w-50 mx-auto rounded-circle"/>
        <div className="card-body">
          <h4>{recipe.recipe.label}</h4>
        </div>
            <Dropdown>
      <Dropdown.Toggle variant="success" id="dropdown-basic">
     <b> CLICK TO SEE RECIPE</b>
      </Dropdown.Toggle>

      <Dropdown.Menu className='drop'>
<ul className="list-group list-group-flush">
          {
           recipe.recipe.ingredientLines.map(ingredient => <li className="list-group-item">{ingredient}</li>)
          }
        </ul>
      </Dropdown.Menu>
    </Dropdown>

       </div>

       </div>
      ))}
    </div>
    </div>
  );
};

export default Home;