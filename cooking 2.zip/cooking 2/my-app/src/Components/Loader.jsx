import React from 'react'

export default function Loader() {
   setTimeout(Button, 3000);
 function Button()
 {
 document.location.href = 'http://localhost:3000/Home';
 }
  return (
    <div>
    <div className='loader'>  <div className="spinner-border"></div></div>

    </div>
  )
}
